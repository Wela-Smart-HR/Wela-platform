import { initializeApp } from "firebase/app";
import { getFirestore, serverTimestamp } from "firebase/firestore";
import { getAuth } from "firebase/auth";

export const firebaseConfig = {
  apiKey: "AIzaSyD2Rnx0rkwI6DqathSSJRjfQF2fNwDTtEA",
  authDomain: "smart-hr-app-cc978.firebaseapp.com",
  projectId: "smart-hr-app-cc978",
  storageBucket: "smart-hr-app-cc978.firebasestorage.app",
  messagingSenderId: "440417818460",
  appId: "1:440417818460:web:c782e58b1047f4ce865399",
  measurementId: "G-Y6NKM1B7FX"
};

let app;
let db;
let auth;

// Safety Check: ตรวจสอบว่ามี projectId ไหมก่อนเริ่มทำงาน
if (firebaseConfig.projectId) {
    try {
        app = initializeApp(firebaseConfig);
        db = getFirestore(app);
        auth = getAuth(app);
        console.log("🔥 Firebase Connected Successfully");
    } catch (error) {
        console.error("🔥 Firebase Connection Error:", error);
    }
} else {
    console.error("⚠️ Firebase Config is missing!");
}

export { db, auth, serverTimestamp };